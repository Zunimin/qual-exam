class Manufacturer:
    def __init__(self, manufacturer_id: int, manufacturer_name: str):
        self.manufacturer_id = manufacturer_id
        self.manufacturer_name = manufacturer_name

    def __str__(self):
        return f"{self.manufacturer_id};{self.manufacturer_name}"

    def __repr__(self):
        return self.__str__()