class Equipment:
    def __init__(self, equipment_type_id: int, equipment_name: str):
        self.equipment_type_id = equipment_type_id
        self.equipment_name = equipment_name

    def __str__(self):
        return f"{self.equipment_type_id};{self.equipment_name}"

    def __repr__(self):
        return self.__str__()