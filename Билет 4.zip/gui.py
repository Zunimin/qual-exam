import sys
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton, QMessageBox
)
from service import WorkShop


class WorkShopWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.workshop = WorkShop()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Гарантийная мастерская")
        self.setFixedSize(300, 150)

        layout = QVBoxLayout()

        self.btn_unfinished = QPushButton("Список невыполненных ремонтов")
        self.btn_unfinished.clicked.connect(self.generate_unfinished)
        layout.addWidget(self.btn_unfinished)

        self.btn_complex = QPushButton("Список сложных ремонтов")
        self.btn_complex.clicked.connect(self.generate_complex)
        layout.addWidget(self.btn_complex)

        self.setLayout(layout)

    def generate_unfinished(self):
        try:
            self.workshop.save_unfinished_repairs()
            QMessageBox.information(
                self,
                "Успех",
                "Список невыполненных ремонтов сохранен в файл 'unfinished_repairs.txt'")
        except Exception as e:
            QMessageBox(
                self,
                "Ошибка",
                f"Не удалось создать отчет: {str(e)}")

    def generate_complex(self):
        try:
            self.workshop.save_complex_repairs()
            QMessageBox.information(
                self,
                "Успех",
                "Список невыполненных ремонтов сохранен в файл 'complex_repairs.txt'"
            )
        except Exception as e:
            QMessageBox.information(
                self,
                "Ошибка",
                f"Не удалось создать отчет: {str(e)}"
            )
