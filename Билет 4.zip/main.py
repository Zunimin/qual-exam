
from database import get_connection
from service import WorkShop
from gui import WorkShopWindow
import sys
from PyQt6.QtWidgets import QApplication


def load_data():
    workshop = WorkShop()

    workshop.load_manufacturers()
    workshop.load_equipments()
    workshop.load_clients()
    workshop.load_categories()
    workshop.load_repairs()

    print("Данные успешно загружены в БД")


def main():

    load_data()

    app = QApplication(sys.argv)
    window = WorkShopWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
