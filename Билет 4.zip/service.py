from database import get_connection
from manufacturer import Manufacturer
from equipment import Equipment
from client import Client
from category import Category
from repair import Repair


class WorkShop:
    def load_manufacturers(self, filename="manufacturers.txt"):
        connection = get_connection()
        cursor = connection.cursor()

        with open(filename, 'r', encoding="utf-8") as file:
            for line in file:
                manufacturer_id, manufacturer_name = line.strip().split(';')

                cursor.execute("INSERT OR REPLACE INTO manufacturers VALUES (?, ?)",
                               (int(manufacturer_id), manufacturer_name)
                               )

        connection.commit()
        connection.close()

    def load_equipments(self, filename="equipments.txt"):
        connection = get_connection()
        cursor = connection.cursor()

        with open(filename, 'r', encoding="utf-8") as file:
            for line in file:
                equipment_type_id, equipment_name = line.strip().split(';')

                cursor.execute("INSERT OR REPLACE INTO equipments VALUES (?, ?)",
                               (int(equipment_type_id), equipment_name)
                               )

        connection.commit()
        connection.close()

    def load_clients(self, filename="clients.txt"):

        connection = get_connection()
        cursor = connection.cursor()

        with open(filename, 'r', encoding="utf-8") as file:
            for line in file:
                client_id, client_fio, client_address = line.strip().split(';')

                cursor.execute("INSERT OR REPLACE INTO clients VALUES (?, ?, ?)",
                               (int(client_id), client_fio, client_address)
                               )

        connection.commit()
        connection.close()

    def load_categories(self, filename="categories.txt"):
        connection = get_connection()
        cursor = connection.cursor()

        with open(filename, 'r', encoding="utf-8") as file:
            for line in file:
                category_id, category_name = line.strip().split(';')

                cursor.execute("INSERT OR REPLACE INTO categories VALUES (?, ?)",
                               (int(category_id), category_name)
                               )

        connection.commit()
        connection.close()

    def load_repairs(self, filename="repairs.txt"):
        connection = get_connection()
        cursor = connection.cursor()
        with open(filename, 'r', encoding="utf-8") as file:
            for line in file:
                repair_id, client_id, equipment_type_id, category_id, equipment_name, date_of_request, date_of_execution = line.strip().split(';')

                cursor.execute("INSERT OR REPLACE INTO repairs VALUES (?, ?, ?, ?, ?, ?, ?)",
                               (int(repair_id), int(client_id), int(equipment_type_id), int(category_id),
                                equipment_name, date_of_request, date_of_execution)
                               )
        connection.commit()
        connection.close()

    def save_unfinished_repairs(self, filename="unfinished_repairs.txt"):
        connection = get_connection()
        cursor = connection.cursor()

        cursor.execute("SELECT * FROM repairs WHERE date_of_execution = '' OR date_of_execution IS NULL")

        repairs = cursor.fetchall()

        cursor.execute("SELECT * FROM clients")
        clients = {client[0]: client[1] for client in cursor.fetchall()}

        cursor.execute("SELECT * FROM categories")
        categories = {category[0]: category[1] for category in cursor.fetchall()}

        connection.close()

        with open(filename, 'w', encoding="utf-8") as file:
            file.write("Код ремонта;Клиент;Техника;Категория ремонта;Дата обращения\n")

            for repair in repairs:
                repair_id, client_id, equipment_type_id, category_id, equipment_name, date_of_request, date_of_execution = repair

                client_name = clients.get(client_id, "Неизвестно")
                category_name = categories.get(category_id, "Неизвестно")

                file.write(f"{repair_id};{client_name};{equipment_name};{category_name};{date_of_request}")

        print(f"Невыполненные ремонты сохранены в файл {filename}")

    def save_complex_repairs(self, filename="complex_repairs.txt"):
        connection = get_connection()
        cursor = connection.cursor()

        cursor.execute("SELECT * FROM repairs")
        repairs = cursor.fetchall()

        connection.close()

        with open(filename, 'w', encoding="utf-8") as file:
            file.write("Код ремонта;Название техники;Дата обращения\n")
            for repair in repairs:
                repair_id = repair[0]
                equipment_name = repair[4]
                date_request = repair[5]
                category_id = repair[3]

                if category_id == 200:
                    file.write(f"{repair_id};{equipment_name};{date_request}\n")

        print(f"Список сложных ремонтов сохранен в файл {filename}")
