class Client:
    def __init__(self, client_id: int, client_fio: str, client_address: str):
        self.client_id = client_id
        self.client_fio = client_fio
        self.client_address = client_address

    def __str__(self):
        return f"{self.client_id};{self.client_fio};{self.client_address}"

    def __repr__(self):
        return self.__str__()