class Repair:
    def __init__(self, repair_id: int, client_id: int, equipment_type_id: int, category_id: int, equipment_name: str,
                 date_of_request: str, date_of_execution: str):
        self.repair_id = repair_id
        self.client_id = client_id
        self.equipment_type_id = equipment_type_id
        self.category_id = category_id
        self.equipment_name = equipment_name
        self.date_of_request = date_of_request
        self.date_of_execution = date_of_execution

    def __str__(self):
        return (f"{self.repair_id};{self.client_id};{self.equipment_type_id};{self.category_id};"
                f"{self.equipment_name};{self.date_of_request};{self.date_of_execution}")

    def __repr__(self):
        return self.__str__()
